package com.telusco.SpringJDBCEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcExApplicationTests {

	@Test
	void contextLoads() {
	}

}
